.screenshot-box .left-side ul.features li {background-image:url(<?php echo THEME_BASE_URI; ?>/images/ok2.png);}
.screenshot-box.kl-style-1 .thescreenshot { background-image:url(<?php echo THEME_BASE_URI; ?>/images/screenshotbox-bg.png);}
.screenshot-box.kl-style-2 .left-side ul.features li {background-image:url(<?php echo THEME_BASE_URI; ?>/images/ok3.png);}
.screenshot-box--dark .left-side ul.features li {background-image:url(<?php echo THEME_BASE_URI; ?>/images/ok2_invert.png);}
.screenshot-box--dark.kl-style-2 .left-side ul.features li {background-image:url(<?php echo THEME_BASE_URI; ?>/images/ok3_invert.png);}