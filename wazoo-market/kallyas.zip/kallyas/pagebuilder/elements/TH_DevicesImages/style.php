.el-di-type--img .el-di__laptop { height: 670px; background-image: url(<?php echo THEME_BASE_URI; ?>/images/devices/macbook.png); }
.el-di-type--vector .el-di__laptop { height: 600px; background-image: url(<?php echo THEME_BASE_URI; ?>/images/devices/macbook-air.svg); }
.el-di-type--img .el-di__smartphone { height: 403px; width: 245px; background-image: url(<?php echo THEME_BASE_URI; ?>/images/devices/iphone6.png); }
.el-di-type--vector .el-di__smartphone { height: 400px; width: 200px; left: 110px; background-image: url(<?php echo THEME_BASE_URI; ?>/images/devices/iphone6.svg); }