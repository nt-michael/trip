<?php if(! defined('ABSPATH')){ return; }
/**
* Single Related Title
*/
?>
<h3 class="rta-title kl-blog-related-title"><?php _e( 'What you can read next', 'zn_framework' ); ?></h3>
