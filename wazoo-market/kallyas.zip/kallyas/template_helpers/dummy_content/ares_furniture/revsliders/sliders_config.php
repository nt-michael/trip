<?php

$revSlidersConfig = array(
	array(
		'name' => 'alternative-slider',
		'file' => 'alternative-slider.zip'
	),
	array(
		'name' => 'homepage-slider',
		'file' => 'homepage-slider.zip'
	),
);
