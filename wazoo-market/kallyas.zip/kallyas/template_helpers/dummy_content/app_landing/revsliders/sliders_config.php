<?php

$revSlidersConfig = array(
	array(
		'file' => 'app-landing-slider.zip'
	),
);
