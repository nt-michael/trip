<?php

$revSlidersConfig = array(
	array(
		'file' => 'main.zip'
	),
);
