<?php if(! defined('ABSPATH')) { return; }
/**
 * Custom Classes
 *
 * @package  Kallyas
 * @category Custom Classes
 * @author Team Hogash
 * @since 3.8.0
 */

if(! class_exists('WpkZn'))
{
	/**
	 * Class WpkZn
	 *
	 * @category Custom Classes
	 * @author Team Hogash
	 */
	class WpkZn
	{

		/**
		 * Retrieve all sidebars from the theme.
		 * @since 4.0.0
		 * @return array
		 */
		public static function getThemeSidebars(){
			$sidebars = array ();
			$sidebars['defaultsidebar'] = __( 'Default Sidebar', 'zn_framework' );
			if ( $unlimited_sidebars = zget_option( 'unlimited_sidebars', 'unlimited_sidebars' ) ) {
				foreach ( $unlimited_sidebars as $sidebar ) {
					if (isset($sidebar['sidebar_name']) && !empty($sidebar['sidebar_name'])) {
						$sidebars[ $sidebar['sidebar_name'] ] = $sidebar['sidebar_name'];
					}
				}
			}
			return $sidebars;
		}

		/**
		 * Retrieve all headers from the theme.
		 * @since 4.0.0
		 * @return array
		 */
		public static function getThemeHeaders( $addnone = false ){

			$headers = array ();
			if($addnone == true){
				$headers[0] = 'None';
			}
			$headers['zn_def_header_style'] = __( 'Default style', 'zn_framework' );
			$saved_headers = zget_option( 'header_generator', 'unlimited_header_options', false, array() );
			foreach ( $saved_headers as $header ) {
				if ( isset ( $header['uh_style_name'] ) && ! empty ( $header['uh_style_name'] ) ) {
					$header_name             = strtolower( str_replace( ' ', '_', $header['uh_style_name'] ) );
					$header_name             = sanitize_html_class( $header_name );
					$headers[ $header_name ] = $header['uh_style_name'];
				}
			}

			return $headers;
		}

		/**
		 * Retrieve all blog categories as an associative array: id => name
		 * @since 4.0.0
		 * @return array
		 */
		public static function getBlogCategories(){
			$args = array (
				'type'         => 'post',
				'child_of'     => 0,
				'parent'       => '',
				'orderby'      => 'id',
				'order'        => 'ASC',
				'hide_empty'   => 1,
				'hierarchical' => 1,
				'taxonomy'     => 'category',
				'pad_counts'   => false
			);
			$blog_categories = get_categories( $args );

			$categories = array ();
			foreach ( $blog_categories as $category ) {
				$categories[ $category->cat_ID ] = $category->cat_name;
			}
			return $categories;
		}

		/**
		 * Retrieve all shop categories as an associative array: id => name
		 * @requires plugin WooCommerce installed and active
		 * @since 4.0.0
		 * @return array
		 */
		public static function getShopCategories(){
			$args = array (
				'type'         => 'shop',
				'child_of'     => 0,
				'parent'       => '',
				'orderby'      => 'id',
				'order'        => 'ASC',
				'hide_empty'   => 1,
				'hierarchical' => 1,
				'taxonomy'     => 'product_cat',
				'pad_counts'   => false
			);

			$shop_categories = get_categories( $args );

			$categories = array ();
			if ( ! empty( $shop_categories ) ) {
				foreach ( $shop_categories as $category ) {
					if ( isset( $category->cat_ID ) && isset( $category->cat_name ) ) {
						$categories[ $category->cat_ID ] = $category->cat_name;
					}
				}
			}
			return $categories;
		}

		/**
		 * @wpk
		 * Retrieve all product tags
		 * @since v4.1
		 * @return array
		 */
		public static function getShopTags(){
			$terms = get_terms( 'product_tag', array(
				'orderby' => 'name',
				'order' => 'ASC',
				'hide_empty' => false,
			) );
			if(! $terms || is_wp_error($terms)){
				return array();
			}
			$temp = array();
			foreach($terms as $tag){
				$temp[$tag->term_id] = esc_attr($tag->name);
			}
			return $temp;
		}



		/**
		 * Retrieve the list of all Portfolio Categories
		 * @since 4.0.0
		 * @return array
		 */
		public static function getPortfolioCategories(){
			$args = array (
				'type'         => 'portfolio',
				'child_of'     => 0,
				'parent'       => '',
				'orderby'      => 'id',
				'order'        => 'ASC',
				'hide_empty'   => 1,
				'hierarchical' => 1,
				'taxonomy'     => 'project_category',
				'pad_counts'   => false
			);
			$port_categories = get_categories( $args );
			$categories = array ();
			if ( ! empty( $port_categories ) ) {
				foreach ( $port_categories as $category ) {
					if ( isset( $category->cat_ID ) && isset( $category->cat_name ) ) {
						$categories[ $category->cat_ID ] = $category->cat_name;
					}
				}
			}
			return $categories;
		}

		/**
		 * Retrieve the list of tags (as links) for the specified post
		 * @param int $postID
		 * @param string $sep The separator
		 * @return string
		 */
		public static function getPostTags($postID, $sep = '')
		{
			$out = '';
			$tagsArray = array();
			$tags = wp_get_post_tags($postID, array('orderby' => 'name', 'order' => 'ASC'));
			if(empty($tags)){
				return $out;
			}
			foreach($tags as $tag){
				$tagsArray[$tag->name] = get_tag_link($tag->term_id);
			}
			foreach($tagsArray as $name => $link){
				$out .= '<a class="kl-blog-tag" href="'.$link.'" rel="tag">'.$name.'</a>';
				if(! empty($sep)){
					$out .= $sep;
				}
			}
			$out = rtrim($out, $sep);
			return $out;
		}
	}

}



if(! class_exists('WpkPageHelper')) {
	/**
	 * Class WpkPageHelper
	 *
	 * Helper class to manage various aspects from pages
	 *
	 * @package  Kallyas
	 * @category UI
	 * @author   Team Hogash
	 * @since    4.0.0
	 */
	class WpkPageHelper
	{

		/**
		 * Display the proper sub-header based on the provided arguments
		 *
		 * @param array $args The list of arguments
		 */
		public static function zn_get_subheader( $args = array(), $is_pb_element = false )
		{

			$config = zn_get_pb_template_config();
			if( $config['template'] !== 'no_template' && ! $is_pb_element ){
				// We have a subheader template... let's get it's possition
				$pb_data = get_post_meta( $config['template'], 'zn_page_builder_els', true );

				if( $config['location'] == 'before' ){
					ZNPB()->zn_render_uneditable_content( $pb_data );
					self::render_sub_header( $args );
				}
				elseif( $config['location'] == 'replace' ){
					ZNPB()->zn_render_uneditable_content( $pb_data );
				}
				elseif( $config['location'] == 'after' ){
					self::render_sub_header( $args );
					ZNPB()->zn_render_uneditable_content( $pb_data );
				}
			}
			else{
				self::render_sub_header( $args );
			}

		}

		public static function render_sub_header( $args = array() ){
			$id = zn_get_the_id();

			// Breadcrumb / Date
			$default_bread = zget_option( 'def_header_bread', 'general_options', false, 1 );
			$default_date = zget_option( 'def_header_date', 'general_options', false, 1 );

			// Title / Subtitle
			$show_title = zget_option( 'def_header_title', 'general_options', false, 1 );
			$show_subtitle = zget_option( 'def_header_subtitle', 'general_options', false, true );

			$def_subheader_alignment = zget_option( 'def_subheader_alignment', 'general_options', false, 'right' );

			$def_subheader_textcolor = zget_option( 'def_subh_textcolor', 'general_options', false, 'light' );

			$defaults = array(
				'headerClass' => 'zn_def_header_style',
				'title' => get_the_title( $id ),
				'layout' => zget_option( 'zn_disable_subheader', 'general_options' ),
				'def_header_bread' => $default_bread,
				'def_header_date' => $default_date,
				'def_header_title' => $show_title,
				'show_subtitle' => $show_subtitle,
				'extra_css_class' => '',
				'bottommask' => zget_option( 'def_bottom_style', 'general_options', false, 'none' ),
				'bottommask_bg' => '',
				'bg_source' => '',
				'is_element' => false,
				'inherit_head_pad' => true,
				'subheader_alignment' => $def_subheader_alignment,
				'subheader_textcolor' => $def_subheader_textcolor,
				'title_tag' => 'h2',
				'subtitle_tag' => 'h4'
		   );

			$saved_headers = zget_option( 'header_generator', 'unlimited_header_options', false, array() );

			// Combine defaults with the options saved in post meta
			if ( is_singular() ) {
			// if ( is_singular() || is_home() || is_shop() ) {
				$post_defaults = array();
				$title_bar_layout = get_post_meta( $id, 'zn_zn_disable_subheader', true );

				//@wpk: empty means Default - Set from theme options
				if(empty($title_bar_layout)){
					// "no" means show subheader
					if('no' == ($state = zget_option( 'zn_disable_subheader', 'general_options' ))){
						$post_defaults = array( 'layout' => $state,
												'subtitle' => get_post_meta( $id, 'zn_page_subtitle', true ), );
						$saved_title = get_post_meta( $id, 'zn_page_title', true );
						if ( !empty( $saved_title ) ) {
							$post_defaults['title'] = $saved_title;
						}
					}
				}
				else {
					$post_defaults = array( 'layout' => $title_bar_layout,
											'subtitle' => get_post_meta( $id, 'zn_page_subtitle', true ), );
					$saved_title = get_post_meta( $id, 'zn_page_title', true );
					if ( !empty( $saved_title ) ) {
						$post_defaults['title'] = $saved_title;
					}
				}

				// Sub-header style
				$zn_subheader_style = get_post_meta( $id, 'zn_subheader_style', true );
				if ( !empty( $zn_subheader_style ) ) {
					$post_defaults['headerClass'] = 'uh_' . $zn_subheader_style;
				}

				// Get Subheader settings from Unlimited Subheader style
				foreach ( $saved_headers as $header ) {
					if ( isset ( $header['uh_style_name'] ) && ! empty ( $header['uh_style_name'] ) ) {
						$header_name = strtolower( str_replace( ' ', '_', $header['uh_style_name'] ) );
						if($zn_subheader_style == $header_name){
							// Bottom Mask
							$defaults['bottommask'] = $header['uh_bottom_style'];
							// Text Color
							if(isset($header['uh_textcolor'])){
								$defaults['subheader_textcolor'] = $header['uh_textcolor'];
							}
						}
					}
				}

				$defaults = wp_parse_args( $post_defaults, $defaults );
			}
			elseif ( is_tax() || is_category() ) {
				global $wp_query;
				$cat = $wp_query->get_queried_object();
				if ( $cat && isset( $cat->term_id ) ) {
					$id = $cat->term_id;
					$ch = get_option( 'wpk_zn_select_custom_header_' . $id, false );
					if ( !empty( $ch ) ) {

						if ( 'zn_def_header_style' != $ch ) {
							$defaults['headerClass'] = 'uh_' . $ch;
						}

						// Get Subheader settings from Unlimited Subheader style
						foreach ( $saved_headers as $header ) {
							if ( isset ( $header['uh_style_name'] ) && ! empty ( $header['uh_style_name'] ) ) {
								$header_name = strtolower( str_replace( ' ', '_', $header['uh_style_name'] ) );
								if($ch == $header_name){
									// Bottom Mask
									$defaults['bottommask'] = $header['uh_bottom_style'];
									// Text Color
									if(isset($header['uh_textcolor'])){
										$defaults['subheader_textcolor'] = $header['uh_textcolor'];
									}
								}
							}
						}

					}
				}
			}
			$args = wp_parse_args( $args, $defaults );
			$args = apply_filters( 'zn_sub_header', $args );

			// If the subheader shouldn't be shown
			if ( $args['layout'] == 'yes' ) {
				return;
			}

			// Get title/subtitle's tag
			$title_heading = apply_filters('zn_subheader_title_tag', $args['title_tag']);
			$subtitle_tag = apply_filters('zn_subheader_subtitle_tag', $args['subtitle_tag']);

			// Breadcrumb / Date defaults
			$args_def_header_bread = $args['def_header_bread'] != '' ? $args['def_header_bread'] : $default_bread;
			$args_def_header_date = $args['def_header_date'] != '' ? $args['def_header_date'] : $default_date;
			// Check for Breadcrumbs or Date
			$br_date = $args_def_header_bread || $args_def_header_date;

			// Compose Classes array
			$extra_classes = array();

			$bottom_mask = $args['bottommask'];
			if ( $bottom_mask != 'none' ) {
				$extra_classes[] = 'maskcontainer--' . $bottom_mask;
			}

			$is_element = $args['is_element'];
			if ( $is_element ) {
				$extra_classes[] = 'page-subheader--custom';
			}
			else {
				$extra_classes[] = 'page-subheader--auto';
			}

			// Inherit heading & padding from Unlimited Subheader styles
			// Enabled by default for autogenerated pages and via option in Custom Subheader Element
			$inherit_head_pad = $args['inherit_head_pad'];
			if ( $inherit_head_pad ) {
				$extra_classes[] = 'page-subheader--inherit-hp';
			}

			$extra_classes[] = $args['headerClass'];
			$extra_classes[] = $args['extra_css_class'];

			// Get Site Header's Position (relative | absolute)
			$header_pos = 'psubhead-stheader--absolute';
			$headerLayoutStyle = zn_get_header_layout();
			if ( zget_option( 'head_position', 'general_options', false, '1' ) != 1 ) {
				if ( $headerLayoutStyle != 'style7' ) {
					$header_pos = 'psubhead-stheader--relative';
				}
			}
			$extra_classes[] = $header_pos;

			// Subheader Alignment
			if(!$br_date){
				$extra_classes[] = 'sh-titles--' . ($args['subheader_alignment'] != '' ? $args['subheader_alignment'] : $def_subheader_alignment);
			}

			// Subheader Text color scheme
			$extra_classes[] = 'sh-tcolor--' . ($args['subheader_textcolor'] != '' ? $args['subheader_textcolor'] : $def_subheader_textcolor);

			// Get markup
			include(locate_template('components/theme-subheader/subheader-default.php'));
		}

		/**
		 * Display the custom bottom mask markup
		 *
		 * @param  [type] $bm The mask ID
		 *
		 * @return [type]     HTML Markup to be used as mask
		 */
		public static function zn_bottommask_markup( $bm, $bgcolor = false ) {}

		/**
		 * Display the custom bottom mask markup
		 *
		 * @param  [type] $bm The mask ID
		 *
		 * @return [type]     HTML Markup to be used as mask
		 */
		public static function zn_background_source( $args = array() )
		{
			$defaults = array(
				'uid' => '',
				'source_type' => '',
				'source_background_image' => array(
					'image' => '',
					'repeat' => 'repeat',
					'attachment' => 'scroll',
					'position' => array(
						'x' => 'left',
						'y' => 'top'
					),
					'size' => 'auto',
				),
				'source_vd_yt' => '',
				'source_vd_self_mp4' => '',
				'source_vd_self_ogg' => '',
				'source_vd_self_webm' => '',
				'source_vd_embed_iframe' => '',
				'source_vd_vp' => '',
				'source_vd_autoplay' => 'yes',
				'source_vd_loop' => 'yes',
				'source_vd_muted' => 'yes',
				'source_vd_controls' => 'yes',
				'source_vd_controls_pos' => 'bottom-right',
				'source_overlay' => 0,
				'source_overlay_color' => '',
				'source_overlay_opacity' => '100',
				'source_overlay_color_gradient' => '',
				'source_overlay_color_gradient_opac' => '100',
				'source_overlay_gloss' => '',
				'source_overlay_custom_css' => '',
				'enable_parallax' => '',
			);

			$args = wp_parse_args( $args, $defaults );
			$bg_source = '';
			$sourceType = $args['source_type'];

			if ( $sourceType ):
				if ( $sourceType == 'image' ) {
					$background_styles = array();
					$background_image = $args['source_background_image']['image'];
					$background_styles[] = 'background-image:url(' . $args['source_background_image']['image'] . ')';
					$background_styles[] = 'background-repeat:' . $args['source_background_image']['repeat'];
					$background_styles[] = 'background-attachment:' . $args['source_background_image']['attachment'];
					$background_styles[] =
						'background-position:' . $args['source_background_image']['position']['x'] . ' ' .
						$args['source_background_image']['position']['y'];
					$background_styles[] = 'background-size:' . $args['source_background_image']['size'];
					if ( !empty( $background_image ) ) {
						$bg_details = 'style="' . implode( ';', $background_styles ) . '"';
						if ( $args['enable_parallax'] == 'yes' ) {
							$bg_details = 'data-parallax="scroll" data-image-src="' . $background_image . '"';
						}
						$bg_source .= '<div class="kl-bg-source__bgimage" ' . $bg_details . '></div>';
					}
				}
				else if ( $sourceType == 'video_self' || $sourceType == 'video_youtube' ) {
					// Source Video
					$bg_source .= '
				<div class="kl-video-container kl-bg-source__video">
					<div class="kl-video-wrapper video-grid-overlay">
				';
					if ( $sourceType == 'video_self' ) {
						$bg_source .= '
						<!-- Self Hosted Video Source -->
						<div
							class="kl-video valign halign"
							style="width: 100%; height: 100%;"
							data-setup=\'{
								"position": "absolute",
								"loop": ' . ( $args['source_vd_loop'] == 'yes' ? 'true' : 'false' ) . ',
								"autoplay": ' . ( $args['source_vd_autoplay'] == 'yes' ? 'true' : 'false' ) . ',
								"muted": ' . ( $args['source_vd_muted'] == 'yes' ? 'true' : 'false' ) . ',
								' . ( $args['source_vd_self_mp4'] ? '"mp4":"' . $args['source_vd_self_mp4'] . '",' :
								'' ) . '
								' . ( $args['source_vd_self_webm'] ? '"webm":"' . $args['source_vd_self_webm'] . '",' :
								'' ) . '
								' . ( $args['source_vd_self_ogg'] ? '"ogg":"' . $args['source_vd_self_ogg'] . '",' :
								'' ) . '
								' . ( $args['source_vd_vp'] ? '"fallback_image":"' . $args['source_vd_vp'] . '",' :
								'' ) . '
								"video_ratio": "1.7778"
							}\'
						></div>';
					}
					elseif ( $sourceType == 'video_youtube' ) {
						$bg_source .= '
						<!-- Youtube Source -->
						<div
							class="kl-video valign halign"
							style="width: 100%; height: 100%;"
							data-setup=\'{
								"position": "absolute",
								"loop": ' . ( $args['source_vd_loop'] == 'yes' ? 'true' : 'false' ) . ',
								"autoplay": ' . ( $args['source_vd_autoplay'] == 'yes' ? 'true' : 'false' ) . ',
								"muted": ' . ( $args['source_vd_muted'] == 'yes' ? 'true' : 'false' ) . ',
								' . ( $args['source_vd_yt'] ? '"youtube":"' . $args['source_vd_yt'] . '",' : '' ) . '
								' . ( $args['source_vd_vp'] ? '"fallback_image":"' . $args['source_vd_vp'] . '",' :
								'' ) . '
								"video_ratio": "1.7778"
							}\'
						></div>';
					}
					if ( $args['source_vd_controls'] == 'yes' ) {
						$bg_source .= '
					<ul class="kl-video--controls" data-position="' . $args['source_vd_controls_pos'] . '">
						<li><a href="#" class="btn-toggleplay"><i class="kl-icon glyphicon glyphicon-play circled-icon"></i></a></li>
						<li><a href="#" class="btn-audio"><i class="kl-icon glyphicon glyphicon-volume-up circled-icon ci-xsmall"></i></a></li>
					</ul>';
					}
					$bg_source .= '
					</div>
					<!-- // video-wrapper -->
				</div>
				<!-- // video-container -->
				';
				}
				else if ( $sourceType == 'embed_iframe' ) {
					$source_vd_embed_iframe = $args['source_vd_embed_iframe'];
					$source_vd_vp = $args['source_vd_vp'];

					if ( !empty( $source_vd_embed_iframe ) ) {
						$video_attributes = array(
							'loop' => $args['source_vd_loop'] == 'yes' ? 1 : 0,
							'autoplay' => $args['source_vd_autoplay'] == 'yes' ? 1 : 0
						);
						// Source Video
						$bg_source .= '<div class="kl-bg-source__iframe-wrapper">';
						$bg_source .= '<div class="kl-bg-source__iframe iframe-valign iframe-halign">';
						$bg_source .= get_video_from_link( $source_vd_embed_iframe, 'no-adjust', '100%', null, $video_attributes );
						if(!empty($source_vd_vp)) {
							$bg_source .= '<div style="background-image:url('.$source_vd_vp.');" class="kl-bg-source__iframe-poster"></div>';
						}
						$bg_source .= '</div>';
						$bg_source .= '</div>';
					}
				}
			endif;

			// Overlays
			if ( $args['source_overlay'] != 0 ) {

				$overlay_color = $args['source_overlay_color'];
				$overlay_color_final = $overlay_color;
				// backwards compatibility, check if has separate opacity
				if(strpos($overlay_color, 'rgba') === false ){
					$overlay_opac = $args['source_overlay_opacity'];
					$overlay_color_final = zn_hex2rgba_str( $overlay_color, $overlay_opac );
				}

				$ovstyle = 'background-color:' . $overlay_color_final;
				// Gradient
				if ( $args['source_overlay'] == 2 || $args['source_overlay'] == 3 ) {

					$gr_overlay_color = $args['source_overlay_color_gradient'];
					$gr_overlay_color_final = $gr_overlay_color;

					// backwards compatibility, check if has separate opacity
					if(strpos($gr_overlay_color, 'rgba') === false ){
						$overlay_gr_opac = $args['source_overlay_color_gradient_opac'];
						$gr_overlay_color_final = zn_hex2rgba_str( $gr_overlay_color, $overlay_gr_opac );
					}

					// Gradient Horizontal
					if ( $args['source_overlay'] == 2 ) {
						$ovstyle = 'background:' . $overlay_color_final . '; background: -moz-linear-gradient(left, ' .
								   $overlay_color_final . ' 0%, ' . $gr_overlay_color_final .
								   ' 100%); background: -webkit-gradient(linear, left top, right top, color-stop(0%,' .
								   $overlay_color_final . '), color-stop(100%,' . $gr_overlay_color_final .
								   ')); background: -webkit-linear-gradient(left, ' . $overlay_color_final . ' 0%,' .
								   $gr_overlay_color_final . ' 100%); background: -o-linear-gradient(left, ' .
								   $overlay_color_final . ' 0%,' . $gr_overlay_color_final .
								   ' 100%); background: -ms-linear-gradient(left, ' . $overlay_color_final . ' 0%,' .
								   $gr_overlay_color_final . ' 100%); background: linear-gradient(to right, ' .
								   $overlay_color_final . ' 0%,' . $gr_overlay_color_final . ' 100%); ';
					}
					// Gradient Vertical
					if ( $args['source_overlay'] == 3 ) {
						$ovstyle = 'background: ' . $overlay_color_final . '; background: -moz-linear-gradient(top,  ' .
								   $overlay_color_final . ' 0%, ' . $gr_overlay_color_final .
								   ' 100%); background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,' .
								   $overlay_color_final . '), color-stop(100%,' . $gr_overlay_color_final .
								   ')); background: -webkit-linear-gradient(top,  ' . $overlay_color_final . ' 0%,' .
								   $gr_overlay_color_final . ' 100%); background: -o-linear-gradient(top,  ' .
								   $overlay_color_final . ' 0%,' . $gr_overlay_color_final .
								   ' 100%); background: -ms-linear-gradient(top,  ' . $overlay_color_final . ' 0%,' .
								   $gr_overlay_color_final . ' 100%); background: linear-gradient(to bottom,  ' .
								   $overlay_color_final . ' 0%,' . $gr_overlay_color_final . ' 100%); ';
					}

				}

				// Custom CSS Gradient
				elseif ( $args['source_overlay'] == 4 ) {
					$custom_css_ov = $args['source_overlay_custom_css'];
					$custom_css_ov = preg_replace('!/\*.*?\*/!s', '', $custom_css_ov);
					$custom_css_ov = preg_replace('/\n\s*\n/', "", $custom_css_ov);
					$ovstyle = esc_attr($custom_css_ov);
				}

				$extraclass = '';
				if(isset($args['uid']) && !empty($args['uid']) ){
					$extraclass = 'ov-'.$args['uid'];
				}
				$bg_source .= '<div class="kl-bg-source__overlay '.$extraclass.'" style="' . $ovstyle . '"></div>';

			}
			// Gloss Overlays
			if ( $args['source_overlay_gloss'] == 1 ) {
				$bg_source .= '<div class="kl-bg-source__overlay-gloss"></div>';
			}
			if ( $bg_source != '' ) {
				echo '<div class="kl-bg-source">' . $bg_source . '</div>';
			}
		}

		/**
		 * Display the page header for Documentation pages
		 * Will be removed in 4.1
		 *
		 * @internal
		 * @deprecated 4.0.11
		 */
		public static function zn_get_documentation_header(){}

		/**
		 * Display the site header
		 * Will be removed in 4.1
		 *
		 * @since 4.0
		 * @deprecated 4.0.10
		 */
		public static function displaySiteHeader(){}
	}
}
